# -*- coding: utf-8 -*-
"""
Created on Mon Mar 29 23:41:34 2021

@author: verma
"""

# Q2
import matplotlib.pyplot as plt
import numpy as np

# Q2-1
def k(n):
     if n<3:
        return 3
     elif n>=3:
        return k(n-1)+k(n-3)
def f(n):
     if n<2:
        return 2
     elif n>=2:
        return 1.65*f(n-1)
def g(n):
     if n<2:
        return 1
     elif n>=2:
        return g(n-1)+g(n-2)
def h(n):
     if n<2:
        return 2
     elif n>=2:
        return 2*h(n-2)
x=[0,1,2,3,4,5,6,7,8,9]
y=[]
y1=[]
y2=[]
y3=[]
for i in x:
    y.append(f(i))
    y1.append(g(i))
    y2.append(h(i))
    y3.append(k(i))
# Q2 - 2
# plot for f(x)
plt.xticks(np.arange(0, 10, 1)) 
plt.title('Plot for f(n)',fontsize=24) 
plt.xlabel('x',fontsize=24)
plt.ylabel('f(x)',fontsize=24)
plt.scatter(x,y)
plt.show()
# plot for g(x)
plt.figure()
plt.xticks(np.arange(0, 10, 1)) 
plt.title('Plot for g(n)',fontsize=24) 
plt.xlabel('x',fontsize=24)
plt.ylabel('g(x)',fontsize=24)
plt.scatter(x,y1)
plt.show()
# plot for h(x)
plt.figure()
plt.xticks(np.arange(0, 10, 1))
plt.title('Plot for h(n)',fontsize=24)  
plt.xlabel('x',fontsize=24)
plt.ylabel('h(x)',fontsize=24)
plt.scatter(x,y2)
plt.show()
# plot for k(x)
plt.figure()
plt.xticks(np.arange(0, 10, 1))  
plt.title('Plot for k(n)',fontsize=24)
plt.xlabel('x',fontsize=24)
plt.ylabel('k(x)',fontsize=24)
plt.scatter(x,y3)
plt.show()