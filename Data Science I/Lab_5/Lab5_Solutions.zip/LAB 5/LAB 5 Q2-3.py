# -*- coding: utf-8 -*-
"""
Created on Thu Mar 25 23:14:35 2021

@author: verma
"""

# Q2 - 3

import matplotlib.pyplot as plt
import numpy as np
def k(n):
     if n<3:
        return 3
     elif n>=3:
        return k(n-1)+k(n-3)
def f(n):
     if n<2:
        return 2
     elif n>=2:
        return 1.65*f(n-1)
def g(n):
     if n<2:
        return 1
     elif n>=2:
        return g(n-1)+g(n-2)
def h(n):
     if n<2:
        return 2
     elif n>=2:
        return 2*h(n-2)    
y=[]
y1=[]
y2=[]
y3=[]
# On increasing the value of a we can change the range of x axis.Let's take a=15
# we get the plot as attached in LAB 5 Folder.We get the plot for larger values of
# x and functions are increasing very fastly i.e slope>>1.
a=10
x=np.arange(0,a,1)
for j in x:
    y.append(f(j))
    y1.append(g(j))
    y2.append(h(j))
    y3.append(k(j))
plt.figure()
plt.plot(x,y,color="blue")
plt.plot(x,y1,color="red")
plt.plot(x,y2,color="yellow")
plt.plot(x,y3,color="green")
plt.title('Plot for f(n),g(n),h(n),k(n)',fontsize=24)
plt.xlabel('x',fontsize=24)
plt.ylabel('y',fontsize=24)
plt.legend(["f(n)", "g(n)","h(n)","k(n)"], loc ="upper left")
plt.xlim([0,a])
plt.xticks(np.arange(0, a, 1))
plt.show()
