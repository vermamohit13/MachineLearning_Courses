# -*- coding: utf-8 -*-
"""
Created on Fri Mar 26 12:22:48 2021

@author: verma
"""
# All parts of Q1 is in this file only


import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
# Use pandas to read the CSV
csvdata = pd.read_csv("Data.csv",sep=",")
# Convert dataframe into a numpy array
foo = csvdata[["State","A","B","C","D","E","F","G","H","I","J","K"]].to_numpy()
# Covert numpy array into a list (of lists)
data = foo.tolist()

def highest(v,s):
    return str(max(v))+" "+s[v.index(max(v))]
def lowest(v,s):
    return str(min(v))+" "+s[v.index(min(v))]
def median(v):
    for i in range(0,len(v)):
        for j in range(i,len(v)):
            if v[i]>v[j] :
                t=v[i]
                v[i]=v[j]
                v[j]=t
    j=(v[int((len(v)-1)/2)]+v[int((len(v)+1)/2)])/2
    return str(round(j,1))
def average(v):
     l=sum(v)/len(v)
     return str(round(l,1))
    
        
f=list(csvdata.F)
g=list(csvdata.G)
k=list(csvdata.K)
d=list(csvdata.D)
e=list(csvdata.E)
s=list(csvdata.State)

# Q1-1(a)
print("Q1\n (a) Population density")
print("Highest = "+highest(f,s)) 
print("Lowest = "+lowest(f,s)) 
print("Median = "+median(f))
print("Average = "+average(f))
# Q1-1(b)
print("Q1\n (b) Percentage of marginal farmers")
print("Highest = "+highest(g,s)) 
print("Lowest = "+lowest(g,s)) 
print("Median = "+median(g))
print("Average = "+average(g))
# Q1-1(c)
print("Q1\n (c) Percentage of women in the overall workforce")
print("Highest = "+highest(k,s)) 
print("Lowest = "+lowest(k,s)) 
print("Median = "+median(k))
print("Average = "+average(k))

# Q1-2
barWidth = 0.25
fig = plt.subplots(figsize =(12,8))
 
br1 = np.arange(len(d))
br2 = [x + barWidth for x in br1]
 
plt.bar(br1, d, color ='r', width = barWidth,
        edgecolor ='grey', label =' Average Percentage area with > 30% slope')
plt.bar(br2, e, color ='g', width = barWidth,
        edgecolor ='grey', label ='Road Density')

plt.xlabel('Data', fontweight ='bold', fontsize = 15)
plt.ylabel('States', fontweight ='bold', fontsize = 15)
plt.xticks([r + barWidth for r in range(len(d))],s,rotation=30)

plt.legend()
plt.show()

# Q1-3
l=[]
s1=[]
p=sorted(d)
for i in p:
    l.append(d.index(i))
for j in l:
    s1.append(s[j])
plt.figure()
plt.xlabel('Average Percentage area with > 30% slope', fontweight ='bold', fontsize = 15)
plt.ylabel('States', fontweight ='bold', fontsize = 15)
plt.xticks([r + barWidth for r in range(len(s1))],s1,rotation=30)
plt.bar(s1[:], p[:],align='center')
plt.show()


