#Mohit Verma
# 9958425215
# B20215
#%%
# Importing Necessary Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn import metrics
from scipy.optimize import linear_sum_assignment
from sklearn.mixture import GaussianMixture
from sklearn.cluster import DBSCAN
# Q1
# Part(a)
df=pd.read_csv("Iris.csv")   # Importing Necessary Libraries
df1=df.iloc[:,:4]           # Dataframe with Species Excluded                                                                                                            
pca=PCA(n_components=2)   # Selecting Required Components as 2                                             
pca.fit(df1)
df1_reduced=pca.fit(df1).transform(df1)                                                                                                                                                         
# The eigen value and vector can be found using the eigen analysis of the correlation matrix             
eigenval,eigenvec=np.linalg.eig(df1.cov())
plt.figure(dpi=1200)
plt.bar([1,2,3,4],eigenval)        #Plotting Eigenvalue vs components                                                                                                                                                                                                                                                                           
plt.xlabel("Component No.")
plt.ylabel("Eigenvalue")
plt.figure(dpi=1200)
plt.scatter(df1_reduced[:,0],df1_reduced[:,1])  # Plotting Reduced Data
plt.xlabel("Component 1")
plt.ylabel("Component 2")
plt.title("Scatter plot of Dimensionally reduced data")
#%%
#  Q2
# Part(a)
# Function to calculate Purity Score
def purity_score(y_true, y_pred):
        # compute contingency matrix (also called confusion matrix)
        contingency_matrix=metrics.cluster.contingency_matrix(y_true, y_pred)
        # Find optimal one-to-one mapping between cluster labels and true labels
        row_ind, col_ind = linear_sum_assignment(-contingency_matrix)
        # Return cluster accuracy
        return contingency_matrix[row_ind,col_ind].sum()/np.sum(contingency_matrix)
p0=[]    # For Principal component-1           
p1=[]    # For Principal component-2                                                                           
for i in df1_reduced:                                                                                        
    p0.append(i[0])                                                                                           
    p1.append(i[1])                                                                                                                                                                                 
Y=list(df['Species'])    
Y_val=[]    
#Converting Species to form 0,1,2               
for i in range(len(Y)):
    if (Y[i]=='Iris-setosa'):
        Y_val.append(0)
    if (Y[i]=='Iris-versicolor'):
        Y_val.append(1)
    if (Y[i]=='Iris-virginica'):
        Y_val.append(2)  
df2=pd.DataFrame(df1_reduced)
df3=pd.DataFrame(df1_reduced)
#Applying Kmeans algorithm
kmeans=KMeans(n_clusters=3)    
predicted=kmeans.fit_predict(df3)   # Kmeans Prediction values for K=3
df3['Cluster']=predicted   
plt.figure(dpi=1200)
plt.scatter(df3.loc[df3['Cluster']==0,0],df3.loc[df3['Cluster']==0,1],marker='*',label='Iris-setosa')
plt.scatter(df3.loc[df3['Cluster']==1,0],df3.loc[df3['Cluster']==1,1],marker='x',label='Iris-versicolor')
plt.scatter(df3.loc[df3['Cluster']==2,0],df3.loc[df3['Cluster']==2,1],label='Iris-virginica')
plt.scatter(kmeans.cluster_centers_[:,0],kmeans.cluster_centers_[:,1],marker='+',color='black')
plt.legend()
plt.show()
# Part(b)
print('Distortion Measure for K=3 is ',kmeans.inertia_)
#Part (c)
print('Purity Score for K=3 is ',purity_score(Y_val,predicted))

# Q3
# Function to calculate KMeans
def kmeans(data,k):
    kmeans = KMeans(n_clusters=k)
    kmeans.fit(data)
    kmeans_prediction = kmeans.predict(data)
    D={'0':[],'1':[],'2':[],'3':[],'4':[],'5':[],'6':[],'7':[]}
    for i in range(len(data)):
        D[str(kmeans_prediction[i])].append(data[i])
    return D,kmeans_prediction,kmeans.inertia_               # kmeans_inertia returns the distortion measure

y_actual=df['Species'].copy()         # y_actual initially contains the species' proper name
for i in range(150):
    if y_actual[i]=="Iris-versicolor":
        y_actual[i]=0
    if y_actual[i]=="Iris-setosa":
        y_actual[i]=1
    if y_actual[i]=="Iris-virginica":
        y_actual[i]=2
# y_actual finally contains the species codefied in 0,1,2
distortion_list=[]                 # keeps the list of distortion values obtained
purity_list=[]            # List for Purity scores
# For loop for K values
for i in [2,3,4,5,6,7]:
    D,class_predicted,distortion=kmeans(df1_reduced,i)
    distortion_list.append(distortion)
    purity=purity_score(y_actual,class_predicted)
    purity_list.append(purity)
   
plt.plot([2,3,4,5,6,7],distortion_list)
plt.scatter([2,3,4,5,6,7],distortion_list)
plt.xlabel(" Number of clusters (k)")
plt.ylabel(" Distortion values")
plt.title(" Q3 \n Distortion values vs K")
plt.show()
print("The purity scores for k=2 to k=7 are :",purity_list)
# %%
# Q4
# Part(a)
df4=pd.DataFrame(df1_reduced)
K = 3
# Applying GMM model with K=3
gmm = GaussianMixture(n_components = K)
gmm.fit(df1_reduced)
gmmpredict=gmm.predict(df1_reduced)
df4['Cluster']=gmmpredict
plt.figure(dpi=1200)
plt.scatter(df4.loc[df4['Cluster']==0,0],df4.loc[df4['Cluster']==0,1],marker='*',label='Iris-versicolor')
plt.scatter(df4.loc[df4['Cluster']==1,0],df4.loc[df4['Cluster']==1,1],marker='x',label='Iris-setosa')
plt.scatter(df4.loc[df4['Cluster']==2,0],df4.loc[df4['Cluster']==2,1],label='Iris-virginica')
plt.scatter(gmm.means_[:,0],gmm.means_[:,1],marker='+',color='black',label='')
plt.legend()
plt.show()
#%%
# Part(b)
print("The distortion measure is ",gmm.score(df1_reduced)*150)
#%%
# Part(c)
print(purity_score(df['Species'],df4['Cluster']))
# %%
# Q5
# Function to calculate GMM for different k
def Gmm(K,data,dist_meas,purity_val,Y_true):
    gmm= GaussianMixture(n_components=K)
    gmm.fit(data)
    predicgmm=gmm.predict(data)
    dist_meas.append(gmm.score(data)*150)
    purity_val.append((purity_score(Y_true,predicgmm)))
dist_meas=[]  # For storing Distortion measure for different k
purity_val=[]   # For storing purity Score for different k
Kval=np.arange(2,8,1)
for i in Kval:
    Gmm(i,df1_reduced,dist_meas,purity_val,df["Species"])
plt.figure(dpi=1200)
plt.plot(Kval,dist_meas)
plt.xlabel("K")
plt.ylabel("Total data log-likelihood")
plt.title("Plot of Total Data likelihood vs K")
print("The purity score for Different K is\n",Kval)
print(purity_val)
#%%
# Q6
e_p_s=[1,5]
min_p=[4,10]
pur_scores=[]
for i in e_p_s:
    for j in min_p:
        #Applying DBSCAN model to our data
        dbscan_model=DBSCAN(eps=i, min_samples=j).fit(df1_reduced)
        DBSCAN_predictions = dbscan_model.labels_
        pur_scores.append(purity_score(df["Species"],DBSCAN_predictions))  # Storing purity scores
        core_samples_mask = np.zeros_like(dbscan_model.labels_, dtype=bool)
        core_samples_mask[dbscan_model.core_sample_indices_] = True
        n_clusters_ = len(set(DBSCAN_predictions))- (1 if -1 in DBSCAN_predictions else 0)
        n_noise_ = list(DBSCAN_predictions).count(-1)
        print(n_clusters_)
        unique_labels = set(DBSCAN_predictions)
        colors = [plt.cm.Spectral(each) for each in np.linspace(0, 1, len(unique_labels))]
        plt.figure(dpi=1200)
        for k, col in zip(unique_labels, colors):
            if k == -1:                 # Black used for noise.
                col = [0, 0, 0, 1]

            class_member_mask = DBSCAN_predictions == k
            xy = df1_reduced[class_member_mask & core_samples_mask]
            plt.plot(xy[:, 0],xy[:, 1],"o",markerfacecolor=tuple(col),markeredgecolor="k",markersize=14,)

            xy = df1_reduced[class_member_mask & ~core_samples_mask]
            plt.plot(xy[:, 0],xy[:, 1],"o",markerfacecolor=tuple(col),markeredgecolor="k",markersize=6,)
        plt.title("Estimated number of clusters: %d" % n_clusters_)
        plt.xlabel("eps = {}& Min_samples ={}".format(i,j))
        plt.show()
        plt.figure()
print("The Purity scores for Dbscan are",pur_scores)
#%%