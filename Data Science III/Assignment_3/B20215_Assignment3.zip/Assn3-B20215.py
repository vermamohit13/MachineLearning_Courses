# -*- coding: utf-8 -*-
"""
Created on Tue Sep 14 20:38:34 2021

@author: verma
Name- Mohit Verma
Roll No- B20215
Contact No.-9958425215
"""
#%%
# Importing necessary libraries

from matplotlib.markers import MarkerStyle
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.decomposition import PCA
import matplotlib as mpl
from scipy.spatial import distance as ssd
mpl.rcParams['figure.dpi']= 300    # For higher picture Quality
#%%
# Q1 (a)
print("------- Q1 -------")
print("Part (a)")
data=pd.read_csv("pima-indians-diabetes.csv")
df=pd.DataFrame(data)
for i in df.columns:
    if i!='class':
        Q1=df[i].quantile(0.25)      # Finding Quantiles
        Q3=df[i].quantile(0.75)
        IQR=Q3-Q1                     # Interquartile Range
        df.loc[(df[i]>Q3+1.5*IQR) | (df[i]<Q1-1.5*IQR),i]=df[i].median()   # Removing Outliers
df1=df.copy()
ormin=(df.min().round(4)) # Min of outlier removed Data
ormax=(df.max().round(4))   # Max of outlier removed Data
for i in df.columns:
    if i!='class':
        prev_min=df[i].min()
        prev_max=df[i].max()
        for j in range(df.shape[0]):
            df.loc[j,i]=(df.loc[j,i]-prev_min)*7/(prev_max-prev_min)+5   # Normalising Data A/C to Formula
nmin=df.min().round(3)   # Min of Normalised  Data
nmax=df.max().round(3)   # Max of Normalised  Data
print(pd.DataFrame({'Outlier Removed Min':ormin,'Outlier Removed Max':ormax,'Normalised Min':nmin,'Normalised Max':nmax}))    
#%%
#Part (b)
print("Part (b)")
Omean=df1.mean().round(4)   # Mean of outlier removed Data
Ostd=df1.std().round(4)    #Standard Deviation of outlier removed Data
for i in df1.columns:
    if i!='class':
        prev_mean=df1[i].mean()
        prev_std=df1[i].std()
        for j in range(df1.shape[0]):
            df1.loc[j,i]=(df1.loc[j,i]-prev_mean)/prev_std   # Standardization A/C to Formula
Smean=df1.mean().round(4)   # Mean of Standardized Data
Sstd=df1.std().round(4)    # Standard Deviation of 
print(pd.DataFrame({'Before_Mean':Omean,'Before_Std':Ostd,'After_Mean':Smean,'After_Std':Sstd}))
#%%
# Q2 (a)
print("------- Q2 -------")
print("Part (a)")
cov=np.array([[13,-3],[-3,5]])    # Covariance Matrix
mean = np.array([0, 0]).transpose()    # Mean matrix
a=np.random.multivariate_normal(mean,cov,[1000])  # Data Sample
dfmulno = pd.DataFrame(a, columns=['A', 'B'])      #DataFrame of samples for plotting
plt.scatter(dfmulno['A'], dfmulno['B']) 
plt.title('Plot of Data Samples')
plt.ylabel('X2')
plt.xlabel('X1')
plt.show()
#%%
#Q2 Part(b)
print("Part (b)")
plt.figure()
w,v=np.linalg.eig(cov)   # Eigenvalues and Eigenvectors
vect1, vect2 = v[:, 0], v[:, 1]   # Eigen Vectors
mean_A, mean_B = dfmulno.mean()  
plt.scatter(dfmulno['A'], dfmulno['B'],marker='.')
plt.quiver(mean_A, mean_B, vect1[0], vect1[1], angles="xy",
           scale=5, color='r', label="Vector1")     # Plotting Eigen Vector1
plt.quiver(mean_A, mean_B, vect2[0], vect2[1], angles="xy",
           scale=5, color='g', label="Vector2")      # Plotting Eigen Vector2
plt.title('Scatter Plot with Eigen Vectors')
plt.ylabel('X2')
plt.xlabel('X1')
plt.show()
plt.figure()
#%%
#Q2 Part(c)
print("Part (c)")
component1 = np.matmul(a, vect1.T)  # Taking components Along vect1
component2 = np.matmul(a, vect2.T)  # Taking components along vect2
projection1 = [[], []]              #Projections along Vect1
projection2 = [[], []]              #Projections along Vect2
# These components are of size 1000
for i in range(component1.size):
    s = component1[i]*vect1.T
    t = component2[i]*vect2.T

    projection1[0].append(s[0])   # Saving projection coordinates
    projection1[1].append(s[1])   # Saving projection coordinates
    projection2[0].append(t[0])   # Saving projection coordinates
    projection2[1].append(t[1])   # Saving projection coordinates

# Now we will plot the scatter plots with projection on Vector1
plt.scatter(dfmulno['A'], dfmulno['B'],marker=".")
plt.scatter(projection1[0], projection1[1],marker=".")
plt.quiver(mean_A, mean_B, vect1[0], vect1[1], angles="xy",
           scale=5, color='r', label="vector1")
plt.quiver(mean_A, mean_B, vect2[0], vect2[1], angles="xy",
           scale=5, color='r', label="vector2")
plt.title('Plot with Projection along 1st Vector')
plt.ylabel('X2')
plt.xlabel('X1')
plt.show()
# Now we will plot the scatter plots with projection on Vector2
plt.figure()
plt.scatter(dfmulno['A'], dfmulno['B'])
plt.scatter(projection2[0], projection2[1],marker=".")

plt.quiver(mean_A, mean_B, vect1[0], vect1[1], angles="xy",
           scale=5, color='r', label="Vector1")
plt.quiver(mean_A, mean_B, vect2[0], vect2[1], angles="xy",
           scale=5, color='r', label="Vector2")
plt.title('Plot with Projection along 2nd Vector')
plt.ylabel('X2')
plt.xlabel('X1')
plt.show()
plt.figure()
#%%
# Part(d)
print("Part (d)")
# A new copy of DataFrame
newdf = pd.DataFrame(np.random.randn(1000, 2), columns=['A', 'B'])
# Reconstruct the data samples using all Eigen Vectors
for i in range(1000):
    newdf.iloc[i] = component1[i] * vect1 + component2[i] * vect2

loss = np.linalg.norm((newdf-dfmulno), None)**2
loss = loss/(1000**0.5)     #Reconstruction Error in terms of Euclidean Distance
print("The Reconstruction Error is: ", loss)
print("The Reconstruction Error (rounded to 3) is: ", round(loss, 3))

#%%
#Q3 
#Part (a)
print("------- Q3 -------")
print("Part (a)")
df1.drop(['class'],axis='columns',inplace=True)  # dropping class column
df1C=df1.cov()        # Making copies
df3=df1.copy()
df4=df3.copy() 
eval,evec=np.linalg.eigh(df1C)      # eigenvalues & eigenvectors of covariance matrix
evals1=eval.tolist()
max_index=[]       # list for storing index of maximum value
# Finding largest and second largest eigenvalues along with index
for i in range(2):
    max = evals1[0]
    maxi = 0
    for j in range(len(evals1)):
        if evals1[j] > max:
            max = evals1[j]
            maxi = j
    max_index.append(maxi)
    evals1.pop(maxi)
print("Eigenvalues are {},{} ".format(eval[max_index[0]],eval[max_index[1]]))
pca=PCA(n_components=2)     #Applying PCA on data
pca.fit(df3)
df3=pca.transform(df1)      #transforming data
print(pca.explained_variance_)    # Variance of data after dim reduction
red_data=pd.DataFrame(df3,columns=['1','2'])  # Dimension reduced Data
plt.figure()
plt.scatter(red_data['1'],red_data['2'])   # Scatter plot for Dimension reduced Data
plt.ylabel('X2')
plt.xlabel('X1')
plt.title("Scatter plot of Dimension reduced Data")
#%%
#Part(b)
print("Part (b)")
plt.figure()
eval=np.sort(eval)[::-1]
plt.bar(np.arange(1,9,1),eval)   #plotting bar plot for eigenvalues
plt.xlabel("Eigenvalue corresponding to Eigenvector no.")
plt.ylabel("Eigenvalues")
plt.title("Plot of Eigen values")
# %%
#Part(C)
print("Part (C)")
Errors=[]               # List for reconstruction error
#Dimension Reduction for l=1,2,...8 for Reconstruction Error
for i in range(1,9):    
    X=df4.copy()
    pca=PCA(n_components=i)
    pca.fit(X)
    X=pca.transform(X)
    if(i>1):
     print(np.cov(X.T))
    X=pca.inverse_transform(X)
    total_loss = np.linalg.norm((df4-X), None)    #Reconstruction Error using Euclidean Distance
    Errors.append(total_loss/(768**0.5))                     #Total Reconstruction Error for l=i
plt.figure()
plt.title("Graph for Reconstruction Error for l=i")
plt.plot(np.arange(1,9,1),Errors,'-o')
plt.xlabel("L")
plt.ylabel("Reconstruction Error")
#%%
#Part(d)
print("Part (D)")
print(df4.cov())    #Covariance Matrix for Original Data
print(np.cov(X.T))  # Covariance Matrix for l=8
#%%
