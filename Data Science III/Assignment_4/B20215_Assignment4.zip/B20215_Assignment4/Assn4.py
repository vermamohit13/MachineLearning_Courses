#B20215
#Mohit Verma
#9958425215


#%%
#Importing necessary libraries
import numpy as np
import pandas as pd
from numpy import linalg
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, accuracy_score

#KNN function for Q1 & Q2
def KNN(K,X_train,X_labeltrain,X_labeltest,X_test):
    knn=KNeighborsClassifier(n_neighbors=K)     # KNN model for k nearest neighbour
    knn=knn.fit(X_train,X_labeltrain)           # fitting trainig data into model
    Xtest_predict=knn.predict(X_test)           # Predicting values of class for each row 

    print('Confusion Matrix for K:',K)
    confusion_mat=confusion_matrix(X_labeltest,Xtest_predict)    # Confusion Matrix for our testing data
    print(confusion_mat)                                             
    acc_score=accuracy_score(X_labeltest,Xtest_predict)              # Accuracy Score for Testing data
    print('Classification Accuracy for K:',K,'is',acc_score)

  
#%%
# Q1-part(a),part(b)
print("Q1-part(a),(b)")
df=pd.read_csv('SteelPlateFaults-2class.csv')          # Reading Data
df=pd.DataFrame(df)
X=df
X_train,X_test,X_labeltrain,X_labeltest=train_test_split(X,df["Class"],test_size=0.3,random_state=42,shuffle=True)    #Splitting data into test data,training data 
X_train.to_csv('SteelPlateFaults-train.csv',index=False)  # Saving test data
X_test.to_csv('SteelPlateFaults-test.csv',index=False)     # Saving train data
for i in [1,3,5]:
    KNN(i,X_train,X_labeltrain,X_labeltest,X_test)          #KNN Function Call
#%%
#Q2-part(a),(b)
print("Q2-part(a),(b)") 
df1=pd.read_csv('SteelPlateFaults-train.csv')     # Reading Training data
df2=pd.read_csv('SteelPlateFaults-test.csv')      # Reading Testing data
# Normalising training and testing data and removing out of bound error in training data 
for i in df1.columns:
    if i!='Class':
        prev_min=df1[i].min()
        prev_max=df1[i].max()
        new_min=0
        new_max=1
        for j in range(df1.shape[0]):
            df1.loc[j,i]=(df1.loc[j,i]-prev_min)*(new_max-new_min)/(prev_max-prev_min)+new_min    #Normalising formula applied on training data
        for j in range(df2.shape[0]):       #Normalising formula applied on testing data along with taking care of out of bound
            if df2.loc[j,i]<prev_min:
                df2.loc[j,i]=0
            elif df2.loc[j,i]>prev_max:
                df2.loc[j,i]=1
            else:
                df2.loc[j,i]=(df2.loc[j,i]-prev_min)*(new_max-new_min)/(prev_max-prev_min)+new_min

df1.to_csv('SteelPlateFaults-train-Normalised.csv',index=False)   #Saving Normalised training data
df2.to_csv('SteelPlateFaults-test-normalised.csv',index=False)     #Saving Normalised training data
df1=df1.drop('Class',axis=1)          #dropping class columns for KNN
df2=df2.drop('Class',axis=1)

for i in [1,3,5]:
    KNN(i,df1,X_labeltrain,X_labeltest,df2)      #KNN Function Call

# %%
#Q3-part(a),(b)
print("Q3-part(a),(b)")
df3=pd.read_csv('SteelPlateFaults-train.csv')      # Reading Training data
df4=pd.read_csv('SteelPlateFaults-test.csv')        # Reading Testing data
df3=df3.drop(['X_Minimum','Y_Minimum','TypeOfSteel_A300','TypeOfSteel_A400'],axis=1)  #Dropping Columns with very high correlation values
df4=df4.drop(['X_Minimum','Y_Minimum','TypeOfSteel_A300','TypeOfSteel_A400'],axis=1)  #Dropping Columns with very high correlation values
x=df3[df3['Class']==0]    #Filtering training data for class=0
z=df3[df3["Class"]==1]    #Filtering training data for class=1
pc0=len(x)/(len(df3))     #Prior probability for class=0
pc1=1-pc0                  #Prior probability for class=1
x=x.drop(["Class"],axis=1)  
z=z.drop(["Class"],axis=1) 
y=df4.drop(["Class"],axis=1)  # Removing class column from training data
mutrain0=np.array(x.mean())   # mean vector for class=0 training data
cov_mat_train0=np.cov(x.T)    # Covariance matrix of class=0 training data
mutrain1=np.array(z.mean())    # mean vector for class=1 training data
cov_mat_train1=np.cov(z.T)     # Covariance matrix of class=0 training data
r=pd.DataFrame(cov_mat_train0)
p=pd.DataFrame(cov_mat_train1)
r.to_csv("Covariance_matrix_Class=0")
p.to_csv("Covariance_matrix_Class=1")
#likelihood function for calculation likelihood of test data 
def likelihood(xval, mval, covmat):
    myMat = np.dot((xval-mval).T, np.linalg.inv(covmat))   # Appliying Likelihood formula(Unimodal Gaussian distribution) to data 
    inside = -0.5*np.dot(myMat, (xval-mval))
    ex = np.exp(inside)
    return(ex/(((2*np.pi)**(23/2) )* ((np.linalg.det(covmat))**0.5)))
predict = []
# Predicting the class of data using the likelihood function
for i in range(len(y)):     
    p0 = likelihood(y.loc[i,:],mutrain0,cov_mat_train0) * pc0
    p1 = likelihood(y.loc[i,:],mutrain1,cov_mat_train1) * pc1
    if p0 > p1:
        predict.append(0)
    else:
        predict.append(1)
s=0
for i,j in zip(predict,df4["Class"]):
    if(i==j):
     s+=1                             #Calculating correct predictions
print("Accuracy",s/336)
print(confusion_matrix(df4["Class"],predict))    #printing confusion matrix for data



# %%
