# B20215
# Mohit Verma
# 9958425215
#%%
import numpy as np            # Importing necessary libraries
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import confusion_matrix , accuracy_score
from sklearn.mixture import GaussianMixture
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import PolynomialFeatures
from sklearn.model_selection import train_test_split

def BayesGM(Q,dftrain1,dftrain2,dftest,testlabel):            #Bayes GMM Function for Q1
    GMM1=GaussianMixture(n_components=Q,covariance_type='full')   #using Gaussian Mixture from sklearn
    GMM2=GaussianMixture(n_components=Q,covariance_type='full')
    GMM1=GMM1.fit(dftrain1)     #fitting the training data for class=0
    GMM2=GMM2.fit(dftrain2)      #fitting the training data for class=1
    predicted=[]
    a=GMM1.score_samples(dftest)
    b=GMM2.score_samples(dftest)
    for i in range(len(a)):    #Predicting classes
        if(a[i]>=b[i]):
            predicted.append(0)
        else:
            predicted.append(1)  
    print("Confusion Matrix for Q:",Q)
    confu_mat=confusion_matrix(testlabel,predicted)   
    print(confu_mat)                    #printing confusion Matrix
    accu_score=accuracy_score(testlabel,predicted)    
    print("The accuracy score is :",accu_score)                   #printing accuracy score

def RegressionA(ab_train,ab_test,ab_labeltrain,p):  #Function for Linear Regression for Q2 & Q4
    p_feature=PolynomialFeatures(p)                     # Using Polynomial feature
    tr_p=p_feature.fit_transform(np.array(ab_train))   #fitting training data
    te_p=p_feature.fit_transform(np.array(ab_test))    #fitting test data
    LR=LinearRegression()                           
    LR.fit(tr_p,np.array(ab_labeltrain).reshape(-1,1))  #fitting training data 
    tr_predicted=LR.predict(tr_p)                 #predicting training data
    te_predicted=LR.predict(te_p)                 #predicting test data
    return tr_predicted,te_predicted 
def RegressionB(ab_train,ab_test,ab_labeltrain,p,d):  #Function for Linear Regression for Q1 & Q3
    p_feature=PolynomialFeatures(p)                         # Using Polynomial feature
    tr_p=p_feature.fit_transform(np.array(ab_train[d]).reshape(-1,1))   #fitting training data
    te_p=p_feature.fit_transform(np.array(ab_test[d]).reshape(-1,1))   #fitting test data 
    LR=LinearRegression()
    LR.fit(tr_p,np.array(ab_labeltrain).reshape(-1,1)) 
    tr_predicted=LR.predict(tr_p)                                #predicting training data
    te_predicted=LR.predict(te_p)                                #predicting training data
    return tr_predicted,te_predicted 
def pltbar(p,X,y,z,r):                                  #plotting bar graph
    plt.figure(dpi=1200)
    plt.bar(p,X)
    plt.xlabel(y)
    plt.ylabel(z)
    plt.title(r)
#%%
 #Part A-Q1   
dftrain=pd.read_csv("SteelPlateFaults-train.csv")   #reading data training data
dftest=pd.read_csv("SteelPlateFaults-test.csv") #reading data testing data
dftrain=dftrain.drop(['X_Minimum','Y_Minimum','TypeOfSteel_A300','TypeOfSteel_A400'],axis=1)
dftrain0=dftrain[dftrain["Class"]==0]
dftrain1=dftrain[dftrain["Class"]==1]
testlabel=dftest['Class']
dftrain0=dftrain0.drop(['Class'],axis=1)
dftrain1=dftrain1.drop(['Class'],axis=1)
dftest=dftest.drop(['X_Minimum','Y_Minimum','TypeOfSteel_A300','TypeOfSteel_A400','Class'],axis=1)
for i in [2,4,8,16]:
    BayesGM(i,dftrain0,dftrain1,dftest,testlabel)    #USing BayesGM function for q=2,4,8,16
# %%
#Part B-Q1
abalone=pd.read_csv('abalone.csv')    #Reading data
ab_train,ab_test,ab_labeltrain,ab_labeltest=train_test_split(abalone,abalone["Rings"],test_size=0.3,random_state=42,shuffle=True) #Splitting data in training and testing data
ab_train.to_csv('abalone-train.csv',index=False)          #Saving training data                      
ab_test.to_csv('abalone-test.csv',index=False)              #Saving training data  
abtrain_corr=[]
col=[] 
for i in ab_train.columns:    #Finding maximum correlation
    if i!='Rings':  
        abtrain_corr.append(ab_train[i].corr(ab_train['Rings']))     
        col.append(i)

tr_predicted,te_predicted=RegressionB(ab_train,ab_test,ab_labeltrain,1,"Shell weight") # Finding predicted Value of training and testing data with p=1
plt.figure(dpi=1200)
plt.scatter(ab_train['Shell weight'],ab_labeltrain,color='green')  #plotting scatter plot
plt.scatter(np.array(ab_train['Shell weight']).reshape(-1,1),tr_predicted,color='red')
plt.xlabel("Shell weight")
plt.ylabel("No. of Rings")
plt.title("Plot of Shell Weight and Rings")
plt.show()
mserr_train=mean_squared_error(np.array(ab_labeltrain).reshape(-1,1),tr_predicted)
mserr_test=mean_squared_error(np.array(ab_labeltest).reshape(-1,1),te_predicted)
print("The RMSE for training data is :",np.sqrt(mserr_train))    #Calculating Root Mean Squared Error for training data
print("The RMSE for testing data is :",np.sqrt(mserr_test))      #Calculating Root Mean Squared Error for training data
plt.figure(dpi=1200)
plt.scatter(np.array(ab_labeltest).reshape(-1,1),te_predicted)  #ploting scared plot of Actual and Predicted Rings
plt.xlabel("Actual Rings")
plt.ylabel("Predicted Rings")
plt.title("Plot of Actual vs Predicted Rings")
plt.show()
# %%
# Part B-Q2
ab_train1=ab_train.copy()  
ab_train=ab_train.drop('Rings',axis=1)    #Dropping Rings Column
ab_test1=ab_test.copy()                     
ab_test=ab_test.drop('Rings',axis=1)      #Dropping Rings Column
tr_predicted,te_predicted=RegressionA(ab_train,ab_test,ab_labeltrain,1)  #Using 
mserr_train=mean_squared_error(np.array(ab_labeltrain).reshape(-1,1),tr_predicted)
mserr_test=mean_squared_error(np.array(ab_labeltest).reshape(-1,1),te_predicted)
print("The RMSE of Training data is :",np.sqrt(mserr_train))    #(A)
print("The RMSE of Testing Data is:",np.sqrt(mserr_test))     #(B)
plt.figure(dpi=1200)   
plt.scatter(np.array(ab_labeltest).reshape(-1,1),te_predicted) 
plt.title("Plot of Actual No. of rings and Predicted Rings")                                                     #(C)
 
plt.show()
#%%
#Part B-Q3
err_train1=[]
p=[2,3,4,5]
err_test1=[]
for i in [2,3,4,5]:  #loop to find regression for p=2,3,4,5
 tr_predicted,te_predicted=RegressionB(ab_train1,ab_test1,ab_labeltrain,i,"Shell weight")
 err_train1.append(np.sqrt(mean_squared_error(np.array(ab_labeltrain).reshape(-1,1),tr_predicted)))
 err_test1.append(np.sqrt(mean_squared_error(np.array(ab_labeltest).reshape(-1,1),te_predicted))) 
plt.figure(dpi=1200)
pltbar(p,err_train1,"p values","RMSE","Plot for training data")   #plotting bar graph of RMSE of training data
pltbar(p,err_test1,"p values","RMSE","Plot for testing data")  #plotting bar graph of RMSE of testing data
tr_predicted,te_predicted=RegressionB(ab_train1,ab_test1,ab_labeltrain,4,"Shell weight")  #Regression with smallest RMSE p=4 ->Observation from graph
plt.figure(dpi=1200)
plt.scatter(ab_train1["Shell weight"],ab_labeltrain,color="green") #Scatter Plot for Shell Weight and Rings 
plt.scatter(np.array(ab_train1["Shell weight"]).reshape(-1,1),tr_predicted,color="red") #Scatter Plot for Shell Weight and Predicted Rings 
plt.xlabel("Shell weight")
plt.ylabel("No. of Rings")
plt.title("Plot of Shell Weight and Rings")
plt.show()
plt.figure()
plt.scatter(np.array(ab_test1["Rings"]).reshape(-1,1),te_predicted)
plt.title("Plot for Actual and Predicted Rings")
plt.xlabel("Actual no.of Rings")
plt.ylabel("Predicted no.of Rings")

#%%
#Part B-Q4
err_train2=[]
err_test2=[]
#ab_train=ab_train.drop('Rings',axis=1)
#ab_test=ab_test.drop('Rings',axis=1)
for i in [2,3,4,5]:
 tr_predicted,te_predicted=RegressionA(ab_train,ab_test,ab_labeltrain,i)
 err_train2.append(np.sqrt(mean_squared_error(np.array(ab_labeltrain).reshape(-1,1),tr_predicted)))
 err_test2.append(np.sqrt(mean_squared_error(np.array(ab_labeltest).reshape(-1,1),te_predicted))) 
tr_predicted,te_predicted=RegressionA(ab_train,ab_test,ab_labeltrain,2)
pltbar(p,err_train2,"p values","RMSE","Plot for training data")
pltbar(p,err_test2,"p values","RMSE","Plot for testing data")
plt.figure()
plt.scatter(np.array(ab_labeltest).reshape(-1,1),te_predicted)
plt.title("Plot for Actual and Predicted Rings")
plt.xlabel("Actual no.of Rings")
plt.ylabel("Predicted no.of Rings")
# %%
