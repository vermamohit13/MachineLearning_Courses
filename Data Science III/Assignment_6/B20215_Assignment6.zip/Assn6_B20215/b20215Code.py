# Mohit Verma
# B20215
# 9958425215
#%%
# Importing necessary Libraries
import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
from statsmodels.tsa.ar_model import AutoReg as AR
from pandas.plotting import lag_plot
import statsmodels.api as sm
from statsmodels.graphics.tsaplots import plot_acf
from sklearn.metrics import mean_squared_error
# Function for MAPE(Mean Absolute Percentage Error)
def MAPE(y_true, y_pred): 
    y_true, y_pred = np.array(y_true), np.array(y_pred)  # Using MAPE Formula
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100
#%%
#Q1
# Part(a)
Data=pd.read_csv("daily_covid_cases.csv")   #Loading Data
xticks=np.arange(0,610,60)                  # xticks for Line Plot
labels=['Feb-20','Apr-20','Jun-20','Aug-20','Oct-20','Dec-20','Feb-21','April-21','Jun-21','Aug-21','Oct-21'] # xlebels for Line Plot
plt.figure(dpi=1200)
plt.plot(Data["Date"],Data["new_cases"])   #Plotting line plot 
plt.xticks(xticks,labels,rotation=90)
plt.xlabel("Timeline")
plt.ylabel("Confirmed Cases")
#%%
# Part(b)
corr=sm.tsa.acf(Data['new_cases'],nlags=1)      #Finding Pearson Correlation Coefficient with lag=1
print("The Correlation Coefficient with time lag=1 is ",corr[1])
#%%
# Part(c)
plt.figure(dpi=1200)
lag_plot(Data["new_cases"],lag=1)    #Plotting scatter plot with lag=1 for new_cases
plt.xlabel("Cases (t)")
plt.ylabel("Cases (t+1)")
plt.title("Scatter Plot of Data with lag Data")
#%%
#Part(d)
Corr=[]
lags=[]
for i in range(1,7):
    corr=sm.tsa.acf(Data["new_cases"],nlags=i)   # Finding Autocorrelation with lags from 1-6
    Corr.append(corr[i])
    lags.append(i)
plt.figure(dpi=1200)
plt.plot(lags,Corr)                            #plotting line plot for autocorrelation for different lags
plt.xlabel("Lags(in Days)")
plt.ylabel("Corr")
plt.title("Line plot of Correlation coefficient for different Lags")
#%%
#part(e)
plot_acf(Data["new_cases"],lags=6)   #plotting the correlogram for different lags
plt.xlabel("Lags(in Days)")
# %%
#Q2
#part(a)
data=pd.read_csv("daily_covid_cases.csv",index_col=['Date'],sep=',')  #Loading Data by taking index_col as Date
test_p = 0.35    # Percentage of Data for Test
X = data.values   
tst_sz = math.ceil(len(X)*test_p)
train, test = X[:len(X)-tst_sz], X[len(X)-tst_sz:]  # Splitting Data
window = 5          # Lag val
model = AR(train, lags=5)   # Making AutoRegression Model 
model_fit = model.fit()     # fit/train the model
coef = model_fit.params       # Get the coefficients of AR model
#%%
# Part(b)
history = train[len(train)-window:]  
history = [history[i] for i in range(len(history))]
predictions = list()   # List to hold the predictions
for t in range(len(test)):
	length = len(history)
	lag = [history[i] for i in range(length-window,length)]   #List of list containing different lags
	yhat = coef[0]
	for d in range(window):                     
		yhat += coef[d+1] * lag[window-d-1]     # predicting 
	obs = test[t]
	predictions.append(yhat)
	history.append(obs)
plt.scatter(predictions,test)   # Plotting Scatter Plot for Prediction and Original Values
plt.xlabel("Predicted Values")
plt.ylabel("Actual Values")
plt.title("Scatter Plot between Actual & Predicted Values")
plt.show()
plt.plot(test,color='cornflowerblue',label="True Values")
plt.plot(predictions, color='red', label="Predicted Values")
plt.ylabel("No. of Cases")
plt.xlabel("No. of Days")
plt.title("Line Plot for Actual & Predicted Values")
plt.legend()
plt.show()
rmspe = float(np.sqrt(np.mean(np.square((test - predictions) / test),axis=0))) * 100  # Calculating Root Mean Squared Percentage Error
print('Test RMSE: %.3f' % rmspe)
print("The Mean Absolute Percentage Error is", MAPE(test,predictions))  # Calculating Mean Absolute Percentage Error
#%%
#Q3
lagval=[1,5,10,15,25]
RMSEP=[]               # List for holding Root Mean Squared Percentage Error for different lags
MAPEL=[]                # List for holding Mean Absolute Percentage Error for different lags
for z in lagval:        # Repeating Q2 for different Lag Values  
    window=z
    history = train[len(train)-window:]
    history = [history[i] for i in range(len(history))]
    predictions=[]
    model = AR(train, lags=window)
    model_fit = model.fit()
    coef = model_fit.params
    for t in range(len(test)):
        length = len(history)
        lag = [history[i] for i in range(length-window,length)]
        yhat = coef[0]
        for d in range(window):
         yhat += coef[d+1] * lag[window-d-1]
        obs = test[t]
        predictions.append(yhat)
        history.append(obs)
    rmspe = float(np.sqrt(np.mean(np.square((test - predictions) / test)))) * 100
    RMSEP.append(rmspe)
    MAPEL.append(MAPE(test,predictions))
plt.figure(dpi=1200)
plt.bar(lagval,RMSEP)
plt.xlabel("Lag Values(in days)")
plt.ylabel("RMSE(%)")
plt.title("Bar Chart for RMSE for different Lags")
plt.figure(dpi=1200)
plt.bar(lagval,MAPEL)
plt.xlabel("Lag Values(in days)")
plt.ylabel("MAPE(%)")
plt.title("Bar Chart for MAPE for different Lags")
#%%
# %%
#Q4
a=2/(len(train)**0.5)
b=sm.tsa.acf(train,nlags=100)
for i in range(100):
    if b[i]<a:
        s=i
        break
window=s-1 # The lag=78
model = AR(train, lags=window)
model_fit = model.fit() # fit/train the model
coef = model_fit.params # Get the coefficients of AR model
#using these coefficients walk forward over time steps in test, onestep each time
history = train[len(train)-window:]
history = [history[i] for i in range(len(history))]
predictions = list() # List to hold the predictions, 1 step at a time
for t in range(len(test)):
    length = len(history)
    lag = [history[i] for i in range(length-window,length)]
    yhat = coef[0] # Initialize to w0
    for d in range(window):
        yhat += coef[d+1] * lag[window-d-1] # Add other values
    obs = test[t]
    predictions.append(yhat) #Append predictions to compute RMSElater
    history.append(obs)
mape=MAPE(test,predictions)
rmspe = float(np.sqrt(np.mean(np.square((test - predictions) / test)))) * 100
print("The MAPE is :",mape)
print("The RMSPE is :",rmspe)
#%%