# -*- coding: utf-8 -*-
"""
Created on Sat Aug 28 10:46:23 2021

@author: verma
"""

#Mohit Verma  
#B20215
#9958425215

# importing necessary libraries
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
pd.options.mode.chained_assignment = None 

# using pandas to input the csv file and making a Data Frame
dfm=pd.read_csv("landslide_data3_miss.csv")      #importing Missing value Csv file
df=pd.read_csv("landslide_data3_original.csv")   #importing Missing value Csv file
dfm=pd.DataFrame(dfm)
df=pd.DataFrame(df)

# Q1

y=[]  # List for missing values in each attribute
x=[]  # List for attribute name
for i in dfm.columns:     # Iterating through all columns
    y.append(dfm[i].isnull().sum())   # Counting missing values
    x.append(i)
plt.bar(x,y)     # plotting Bar graph for missing values
plt.xlabel("Attributes",fontsize=24)    # plotting xaxis label
plt.ylabel('No. of missing values')      # plotting yaxis label
plt.title("Bar Graph for no. of missing values of each attribute")   # plotting Title of graph
plt.show()

#Q2
#(a)
print("Q2\n")
dfm1=dfm.dropna(subset=['stationid']) # dropping values with null values in stationid
print("The total no. of tuples deleted when stationid is missing is",len(dfm)-len(dfm1)) 
print("\n") 
dfm2=dfm1.dropna(thresh=7)  # dropping columns with na values for more than or equal to 3 columns
print("The total no. of tuples deleted when more than 1/3 of attributes are missing is",len(dfm1)-len(dfm2)) 
print("\n")

#Q3
print("Q3\n")
print("The no. of missing values in each attributes are:")
print("\n")

total=0
Na=[]
for i in dfm2.columns:     # Iterating through all columns
    print("{} : {}".format(i,dfm2[i].isnull().sum()))  #printing the missing values in reach attribute
    print("\n")
    total+=dfm2[i].isnull().sum()            #adding missing value of each attribute to find total
    if i!="dates" and i!="stationid":
     Na.append(dfm2[i].isnull().sum())   # storing missing value of each attribute in Na
print("The total no. of missing values are {}".format(total))   
print("\n")

 
#Q4   
#(a)(i)
print("Q3\n")
column_means=dfm2.mean()                                  # means of all the columns
dfm3=dfm2.fillna(value=column_means)                       # filling missing values with mean
print("Comparison of mean,median,mode,standard deviation after mean method") 
print("\n")  
print("\t\t\t\t Missing vlaue file \t\t\t\tOriginal file")
for i,j in zip(dfm3.columns,df.columns):              # Iterating through all columns of original file and replaced value missing value file simultaneously
    if((i!="dates" and j!="dates") and (i!="stationid" and j!="stationid")):
        print(i)
        print("Mean:                 {} \t\t\t\t\t {}".format(round(dfm3[i].mean(),3),round(df[i].mean(),3)))    # printing mean of both dataframe
        print("Median:               {} \t\t\t\t\t {}".format(round(dfm3[i].median(),3),round(df[i].median(),3)))   # printing median of both dataframe
        print("Mode:                 {} \t\t\t\t\t {}".format(round(dfm3[i].mode()[0],3),round(df[i].mode()[0],3)))    # printing mode of both dataframe
        print("Standard Deviation:   {} \t\t\t\t\t {}".format(round(dfm3[i].std(),3),round(df[i].std(),3)))           # printing std dev of both dataframe
print("\n")
#(a)(ii)
# Applying rmse formula and calculation and plots
dn=[]
x1=[]
for i in df.columns:
    if i!="dates" and i!="stationid":
     u=((df[i]-dfm3[i]).fillna(value=0))**2           # finding square of difference from both columns 
     dn.append(u)                                 #appending the square of difference from both columns 
     x1.append(i)                                 #appending column names
y1=[]

for i in range(0,len(dn)):
    sum1=sum(dn[i])                              # sum of all values in dn[i] list
    sum1=(sum1/Na[i])**0.5                       #applying formula on already found sum
    y1.append(sum1)                               # appending RMSE to y1

plt.figure()
plt.bar(x1,y1,log=True)                         # plotting Bar graph on log scale for a better presentation
plt.ylabel("RMSE")                               # plotting yaxis label
plt.xlabel("Attributes")                         # plotting xaxis label
plt.title("The RMSE values when missing values are replaced by Mean Values")      # plotting title

#(b)(i)
print("\n")
dfm4=dfm2.fillna(value=dfm2.interpolate())        # filling missing values with interpolated Values
print("Comparison of mean,median,mode,standard deviation after Interpolation method")
print("\n")
print("\t\t\t\t Missing Value file \t\t\t\t Original file")
for i,j in zip(dfm4.columns,df.columns):
    if((i!="dates" and j!="dates") and (i!="stationid" and j!="stationid")):
        print(i)
        print("Mean:                 {} \t\t\t\t\t {}".format(round(dfm4[i].mean(),3),round(df[i].mean(),3)))   # printing mean of both dataframe
        print("Median:               {} \t\t\t\t\t {}".format(round(dfm4[i].median(),3),round(df[i].median(),3)))    # printing median of both dataframe
        print("Mode:                 {} \t\t\t\t\t {}".format(round(dfm4[i].mode()[0],3),round(df[i].mode()[0],3)))     # printing mode of both dataframe
        print("Standard Deviation:   {} \t\t\t\t\t {}".format(round(dfm4[i].std(),3),round(df[i].std(),3)))              # printing std dev of both dataframe
print("\n")

#(B) (ii)
dn1=[]
for i in df.columns:
    if i!="dates" and i!="stationid":
     u=((df[i]-dfm4[i]).fillna(value=0))**2       # finding square of difference from both columns 
     dn1.append(u)                                 #appending the square of difference from both columns
y2=[]
for i in range(0,len(dn1)):
    sum1=sum(dn1[i])                                 # sum of all values in dn[i] list
    sum1=(sum1/Na[i])**0.5                          #applying formula on already found sum
    y2.append(sum1)                                 # appending RMSE to y2
 
plt.figure()
plt.bar(x1,y2,log=True)                         # plotting Bar graph on log scale for a better presentation
plt.ylabel("RMSE")                               # plotting yaxis label
plt.xlabel("Attributes")                         # plotting xaxis label
plt.title("The RMSE values when missing values are replaced by Interpolated Values")      # plotting title

#Q5
#(a)
plt.figure()
plt.boxplot(dfm4['temperature']) #plotting boxplot for temperature
plt.xticks([1], ["temperature"])       # plotting xaxis label
plt.ylabel('Temperature in °C')             # plotting yaxis label
plt.title("Boxplot for temperature after Interpolation of missing values")    #plotting title
temp=np.array(dfm4['temperature'])   #converting values of temperature in numpy array from interpolated DataFrame
q1T = np.quantile(temp, 0.25)        #finding first quartile
q3T = np.quantile(temp, 0.75)         #finding third quartile
iqrT=q3T-q1T                           #finding interquartile range
upper_boundT = q3T+(1.5*iqrT)          # value of upperlimit of temperature(upper end of whisker)
lower_boundT = q1T-(1.5*iqrT)           # value of lowerlimit of temperature(lower end of whisker)
tempout=temp[(temp<=lower_boundT) | (temp >= upper_boundT)]   #finding outlier according to condition
print("\n")
print("The outliers in Temperature are-\n",*tempout)
plt.figure()
plt.boxplot(dfm4['rain'])   #plotting boxplot for rain
plt.xticks([1], ["rain"])                # plotting xaxis label
plt.ylabel('Rain in ml')                     # plotting yaxis label
plt.title("Boxplot for rain after Interpolation of missing values")    #plotting title
rain=np.array(dfm4['rain'])                  #converting values of rain in numpy array
q1R = np.quantile(rain, 0.25)                #finding first quartile
q3R = np.quantile(rain, 0.75)               #finding third quartile
iqrR=q3R-q1R                                 #finding interquartile range
upper_boundR = q3R+(1.5*iqrR)                 # value of upperlimit of temperature(upper end of whisker)
lower_boundR = q1R-(1.5*iqrR)                 # value of lowerlimit of temperature(lower end of whisker)
rainout=rain[(rain<=lower_boundR) | (rain>= upper_boundR)]   #finding outlier according to condition
print("\n")
print("The outliers in Rain are-\n",*rainout)

#(B)
tempF=np.where((temp<=lower_boundT) | (temp >= upper_boundT),np.median(temp),temp)  # Creating a new np array by replacing outliers with median in temp   
rainF=np.where((rain<=lower_boundR) | (rain >= upper_boundR),np.median(rain),rain)   # Creating a new np array by replacing outliers with median in rain
plt.figure()
plt.boxplot(tempF)                                           # plotting boxplot for temperature after replacing outliers with median
plt.xticks([1], ["temperature"])                                 # plotting xaxis label
plt.ylabel('Temperature in °C')                                        # plotting yaxis label
plt.title("Boxplot for Temperature after replacing outliers with medians")    #plotting title
plt.figure()
plt.boxplot(rainF)                                # plotting boxplot for rain after replacing outliers with median
plt.xticks([1], ["rain"])                                      # plotting xaxis label
plt.ylabel('Rain in ml')                                       # plotting yaxis label
plt.title("Boxplot for rain after replacing outliers with medians")    #plotting title



  
