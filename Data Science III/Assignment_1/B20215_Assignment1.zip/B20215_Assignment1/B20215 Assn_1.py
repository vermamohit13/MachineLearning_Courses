#Mohit Verma  
#B20215
#9958425215

# importing necessary libraries
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# using pandas to input the csv file and making a Data Frame
df=pd.read_csv("pima-indians-diabetes.csv")
df=pd.DataFrame(df)
# Q1
# iterating over all columns except class for mean ,median ,mode ,minimum ,maximum and standard Deviation
for i in df.columns :
 if(i!="class"):
    print("Mean of {} : {}".format(i,df[i].mean()))         # rounding values to 2 digits
    print("Median of {} : {}".format(i,df[i].median()))     # formatting data according to i
    if(len(df[i].mode())==2):
     print("Mode of {} : {},{}".format(i,df[i].mode()[0],df[i].mode()[1]))
    else:
       print("Mode of {} : {}".format(i,df[i].mode()[0]))     
    print("Minimum of {} : {}".format(i,df[i].min()))
    print("Maximum of {} : {}".format(i,df[i].max()))
    print("Standard Deviation of {} : {}".format(i,df[i].std()))

# Q2

# (A)
# iterating over all the columns except Age and class to get scatter plot between Age and the other attributes
plt.rcParams['font.size']='16'
for i in df.columns :
       if(i!="class" and i!="Age"):
        plt.figure()                         # plotting a empty new figure
        plt.scatter(x=df["Age"],y=df[i])     # plotting scatter plot with attribute
        plt.title("Scatter plot between Age & {}.".format(i),fontsize=24)   # adding title
        plt.xlabel("Age",fontsize=24)        # adding x label
        plt.ylabel("{}".format(i),fontsize=24)   # adding y label
        plt.show()                           # showing graph

# (B)
# iterating over all the columns except BMI and class to get scatter plot between BMI and the other attributes
for i in df.columns :
       if(i!="class" and i!="BMI"):
        plt.figure()                       # plotting a empty new figure
        plt.scatter(x=df["BMI"],y=df[i])   # plotting scatter plot with attribute
        plt.title("Scatter plot between BMI & {}.".format(i),fontsize=24)   # adding title
        plt.xlabel("BMI",fontsize=24)        # adding x label
        plt.ylabel("{}".format(i),fontsize=24)   # adding y label
        plt.show()                          # showing graph

# Q3      
# (A)  
# iterating over all the columns except Age and class to get correlation coefficient between Age and the other attributes
# using inbuilt pandas library corr function for correlation values
for i in df.columns:
       if(i!="class" and i!="Age"):
        print("The correlation coefficient between Age & {} is {} ".format(i,df["Age"].corr(df[i],method="pearson")))

# (B)
# iterating over all the columns except BMI and class to get correlation coefficient between Age and the other attributes
# using inbuilt pandas library corr function for correlation values
for i in df.columns :
       if(i!="class" and i!="BMI"):   
        print("The correlation coefficient between BMI & {} is {} ".format(i,(df["BMI"].corr(df[i],method="pearson"))))

# Q4

#plot for pregs

plt.figure()             # plotting a empty new figure
plt.hist(df["pregs"],edgecolor="black")    # plotting histogram with attribute and giving edgecolor
plt.title("Histogram of attribute pregs",fontsize=24)   # adding title
plt.xlabel("pregs",fontsize=24)              # adding x label
plt.ylabel("Frequency",fontsize=24)    # adding y label
plt.grid()                            # plotting grid on figure
plt.show()                     # showing graph

#plot for skin

plt.figure()             # plotting a empty new figure
plt.hist(df["skin"],edgecolor="black")    # plotting histogram with attribute and giving edgecolor
plt.title("Histogram of attribute skin",fontsize=24)   # adding title
plt.xlabel("skin",fontsize=24)                        # adding x label
plt.ylabel("Frequency",fontsize=24)             # adding y label
plt.grid()                         # plotting grid on figure
plt.show()                     # showing graph

# Q5
# filtering dataframe according to class values
x=df[df["class"]==0]       
y=df[df["class"]==1]

# plot for class 1

plt.figure()                # plotting a empty new figure
plt.hist(x["pregs"],bins=np.arange(0,13,2),edgecolor="black")   # plotting histogram with attribute and giving edgecolor
plt.title("Histogram of attribute pregs class=0",fontsize=24)   # adding title
plt.xlabel("pregs",fontsize=24)             # adding x label
plt.ylabel("Frequency",fontsize=24)       # adding y label
plt.grid()                    # plotting grid on figure 
plt.show()                     # showing graph

# plot for class 1
plt.figure()                 # plotting a empty new figure
plt.hist(y["pregs"],bins=np.arange(0,18,2),edgecolor="black")   # plotting histogram with attribute and giving edgecolor
plt.title("Histogram of attribute pregs class=1",fontsize=24)   # adding title
plt.xlabel("pregs",fontsize=24)                   # adding x label
plt.ylabel("Frequency",fontsize=24)           # adding y label
plt.grid()                   # plotting grid on figure 
plt.show()                    # showing graph

# Q6 
# iterating over all the columns except class to get the desired boxplots
for i in df.columns:
   if(i!="class"):
      plt.figure()              # plotting a empty new figure
      plt.boxplot(df[i])         #plotting boxplot
      plt.title("Box plot for {}.".format(i),fontsize=24)  # adding title
      plt.xticks([1],["{}".format(i)])         # giving name to xaxis
      plt.show()                   # showing graph